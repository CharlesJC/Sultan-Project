package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import info.androidhive.navigationdrawer.R;

/**
 * Created by aravias on 17-10-2017.
 */

public class login extends Activity {

    private TextView signup,txtapp,textView2;
    private Button button2,resetpasswordid,button;
    EditText mobilenumedittext,passwordedittext;

    Typeface face;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        signup = (TextView) findViewById(R.id.signup);
        txtapp = (TextView) findViewById(R.id.txtapp);
        textView2 = (TextView) findViewById(R.id.textView2);
        button2 = (Button) findViewById(R.id.button2);
        button = (Button) findViewById(R.id.button);
        resetpasswordid = (Button) findViewById(R.id.resetpasswordid);
        mobilenumedittext = (EditText) findViewById(R.id.mobilenumedittext);
        passwordedittext = (EditText) findViewById(R.id.passwordedittext);
        face = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Regular.ttf");
        signup.setTypeface(face);
        txtapp.setTypeface(face);
        textView2.setTypeface(face);
        resetpasswordid.setTypeface(face);
        button2.setTypeface(face);
        button.setTypeface(face);
        mobilenumedittext.setTypeface(face);
        passwordedittext.setTypeface(face);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newacc = new Intent(login.this, SignupActivity.class);
                startActivity(newacc);

            }
        });
        resetpasswordid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent repwd = new Intent(login.this, Resetpassword.class);
                startActivity(repwd);
            }
        });

    }




}
