package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import info.androidhive.navigationdrawer.R;


public class SignupActivity extends Activity {
    Button signup,button;
    Typeface face;
    EditText editText,edittxtname,edittxtemail,edittxtpass,edittxtconpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        signup = (Button) findViewById(R.id.signup);
        button = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.editText);
        edittxtname = (EditText) findViewById(R.id.edittxtname);
        edittxtemail = (EditText) findViewById(R.id.edittxtemail);
        edittxtpass = (EditText) findViewById(R.id.edittxtpass);
        edittxtconpass = (EditText) findViewById(R.id.edittxtconpass);


        face = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Regular.ttf");
        signup.setTypeface(face);
        button.setTypeface(face);
        editText.setTypeface(face);
        edittxtpass.setTypeface(face);
        edittxtconpass.setTypeface(face);
        edittxtemail.setTypeface(face);
        edittxtname.setTypeface(face);




    }

}
