package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import info.androidhive.navigationdrawer.R;


public class Resetpassword extends Activity {

    Button next;
    EditText e1;
    Typeface face;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resetpassword);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        next = (Button) findViewById(R.id.repwdnext);
        e1 = (EditText) findViewById(R.id.e1);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nxt = new Intent(Resetpassword.this,Otp.class);
                startActivity(nxt);

                face = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Regular.ttf");
                next.setTypeface(face);
                e1.setTypeface(face);


            }
        });


    }
}
