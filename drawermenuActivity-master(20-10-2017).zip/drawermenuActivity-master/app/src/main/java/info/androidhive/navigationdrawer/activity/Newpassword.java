package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import info.androidhive.navigationdrawer.R;


public class Newpassword extends Activity {
    EditText newpass,reppass;
    Button repwdnext;
    Typeface face;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpassword);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        newpass = (EditText) findViewById(R.id.newpass);
        reppass = (EditText) findViewById(R.id.reppass);
        repwdnext = (Button) findViewById(R.id.repwdnext);

        face = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Regular.ttf");
        newpass.setTypeface(face);
        reppass.setTypeface(face);
        repwdnext.setTypeface(face);

    }
}
