package info.androidhive.navigationdrawer.Adapter;

import java.util.ArrayList;

/**
 * Created by aravias on 20-10-2017.
 */

public class BrandInfo {
    private String Name;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public ArrayList<CarInfo> getList() {
        return list;
    }

    public void setList(ArrayList<CarInfo> list) {
        this.list = list;
    }

    private ArrayList<CarInfo> list = new ArrayList<CarInfo>();


}
