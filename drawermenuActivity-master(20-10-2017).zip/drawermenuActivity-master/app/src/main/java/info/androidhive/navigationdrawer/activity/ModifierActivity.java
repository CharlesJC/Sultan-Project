package info.androidhive.navigationdrawer.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import info.androidhive.navigationdrawer.R;

public class ModifierActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier);
    }
}
