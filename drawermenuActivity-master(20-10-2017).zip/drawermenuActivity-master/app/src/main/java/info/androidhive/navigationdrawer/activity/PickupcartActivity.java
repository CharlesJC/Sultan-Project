package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import info.androidhive.navigationdrawer.R;

public class PickupcartActivity extends Activity implements AdapterView.OnItemSelectedListener{

ImageView backarrow;
    Spinner time;
    String times[] = {"6:00 pm","7:00 am"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pickupcart);
backarrow = (ImageView) findViewById(R.id.backarrow);
        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backint = new Intent(PickupcartActivity.this,MainActivity.class);
                startActivity(backint);
            }
        });

        time = (Spinner)findViewById(R.id.spinnertime);



        time.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,R.layout.spinnertime,times);

        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinnertime);

        time.setAdapter(spinnerArrayAdapter);


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
