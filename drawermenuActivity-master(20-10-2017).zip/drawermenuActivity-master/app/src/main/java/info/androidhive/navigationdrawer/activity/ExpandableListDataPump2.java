package info.androidhive.navigationdrawer.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by appraytechnologies on 16-Oct-17.
 */

public class ExpandableListDataPump2 {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail2 = new HashMap<String, List<String>>();

        List<String> cricket2 = new ArrayList<String>();


        expandableListDetail2.put("Terms and Condition", cricket2);

        return expandableListDetail2;
    }
}