package info.androidhive.navigationdrawer.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import info.androidhive.navigationdrawer.Adapter.FirstAdapter;
import info.androidhive.navigationdrawer.R;


public class TwoFragment extends Fragment {

    public TwoFragment() {
        // Required empty public constructor
    }
    private RecyclerView recyclerView1;
    private int[] image = {R.drawable.burger, R.drawable.burgerone};
    FirstAdapter adapter;
    Button plus;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = (FrameLayout) inflater.inflate(R.layout.fragment_one, container, false);


        recyclerView1 = (RecyclerView) view.findViewById(R.id.recyclerView2);
        recyclerView1.setHasFixedSize(true);
        recyclerView1.setLayoutManager(new LinearLayoutManager(getActivity()));


        FirstAdapter adapter = new FirstAdapter(getActivity(), image, plus);
        recyclerView1.setAdapter(adapter);

        return  view;
    }

}
