package info.androidhive.navigationdrawer.Adapter;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import info.androidhive.navigationdrawer.R;

public class BaseAdapter extends BaseExpandableListAdapter {




    private Context context;
    private ArrayList<BrandInfo> deplist;


    public BaseAdapter (Context context,ArrayList<BrandInfo> deplist)
    {
        this.context=context;
        this.deplist=deplist;
    }



    @Override
    public int getGroupCount() {
        return deplist.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {

        ArrayList<CarInfo> productlist = deplist.get(groupPosition).getList();

        return productlist.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return deplist.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        ArrayList<CarInfo> productlist = deplist.get(groupPosition).getList();

        return productlist.get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int i, int i1) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean b, View view, ViewGroup viewGroup) {


        BrandInfo headerinfo = (BrandInfo)getGroup(groupPosition);
        if(view == null)
        {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.branditems,null);
        }

        TextView heading = (TextView)view.findViewById(R.id.heading);
heading.setText(headerinfo.getName().trim());

        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean b, View view, ViewGroup viewGroup) {

        CarInfo detailInfo = (CarInfo) getChild(groupPosition,childPosition);
        if(view == null)
        {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.caritems,null);
        }

        TextView sequence = (TextView)view.findViewById(R.id.branditems);
        sequence.setText(detailInfo.getName().trim()+".");

        TextView childitem = (TextView)view.findViewById(R.id.chinditems);
        childitem.setText(detailInfo.getName().trim());


        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}
