package info.androidhive.navigationdrawer.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import info.androidhive.navigationdrawer.R;


public class Otp extends Activity {
    Button otpnext;
    EditText otp;
    Typeface face;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        otpnext = (Button) findViewById(R.id.otpnext);
        otp = (EditText) findViewById(R.id.otp);

        face = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Regular.ttf");
        otp.setTypeface(face);
        otpnext.setTypeface(face);

        otpnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nxt = new Intent(Otp.this, Newpassword.class);
                startActivity(nxt);
            }
        });


    }
}
