package info.androidhive.navigationdrawer.activity;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import info.androidhive.navigationdrawer.R;

public class DeliveryActivity extends AppCompatActivity {


    Button cont;
    EditText search;
    TextView t1, t2, t3, t4, t5, t6, t7, t8, t10, t11, t12, t13, tvtitle;
    Typeface face;
    ImageView notification, backpress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery);

        notification = (ImageView) findViewById(R.id.notification);
        cont = (Button) findViewById(R.id.cont);
        search = (EditText) findViewById(R.id.search);
        t1 = (TextView) findViewById(R.id.t1);
        t2 = (TextView) findViewById(R.id.t2);
        t3 = (TextView) findViewById(R.id.t3);
        t4 = (TextView) findViewById(R.id.t4);
        t5 = (TextView) findViewById(R.id.t5);
        t6 = (TextView) findViewById(R.id.t6);
        t7 = (TextView) findViewById(R.id.t7);
        t8 = (TextView) findViewById(R.id.t8);
        t10 = (TextView) findViewById(R.id.t10);
        t11 = (TextView) findViewById(R.id.t11);
        t12 = (TextView) findViewById(R.id.t12);
        t13 = (TextView) findViewById(R.id.t13);
        tvtitle = (TextView) findViewById(R.id.tvtitle);

//        this.backpress = (ImageView) findViewById(R.id.backpress);
//        this.backpress.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Intent in = new Intent(DeliveryActivity.this, WelcomeBackServerActivity.class);
//                startActivity(in);
//            }
//        });


        face = Typeface.createFromAsset(getAssets(), "fonts/OpenSans-Semibold.ttf");
        cont.setTypeface(face);
        search.setTypeface(face);
        t1.setTypeface(face);
        t2.setTypeface(face);
        t3.setTypeface(face);
        t4.setTypeface(face);
        t5.setTypeface(face);
        t6.setTypeface(face);
        t10.setTypeface(face);
        t7.setTypeface(face);
        t8.setTypeface(face);
        tvtitle.setTypeface(face);
        t10.setTypeface(face);
        t11.setTypeface(face);
        t12.setTypeface(face);
        t13.setTypeface(face);


        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent button = new Intent(DeliveryActivity.this, DeliveryaddressActivity.class);
               startActivity(button);
            }
        });


    }


}

