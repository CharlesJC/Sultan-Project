package info.androidhive.navigationdrawer.Adapter;

/**
 * Created by aravias on 20-10-2017.
 */

public class CarInfo {

    public String getSequence() {
        return Sequence;
    }

    public void setSequence(String sequence) {
        Sequence = sequence;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    private String Sequence="";
    private String Name="";

}
