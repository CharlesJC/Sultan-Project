package info.androidhive.navigationdrawer.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by appraytechnologies on 16-Oct-17.
 */

public class ExpandableListDataPump {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> cricket = new ArrayList<String>();
        cricket.add("1. Lorem ipsum dolor sit amet, consectetuer adipiscing elit." +
                "Aenean commodo ligula eget dolor. Anenean massa.Cum sociis" +
                "natoque penatibus et magnis dis parturient montes,nascetur" +
                "ridiculus mus");

        cricket.add("2. Donec quam felis,ultricies nec,pellentesque eu, pretium" +
                "quis,sem. Nulla consequat massa quis enim. Donec pede justo," +
                "fringilla vel,aliquet nec, vulputate   eget,arcu.");


        expandableListDetail.put("How Sultan Delight Burger Loyalty Program Works?", cricket);

        return expandableListDetail;
    }
}